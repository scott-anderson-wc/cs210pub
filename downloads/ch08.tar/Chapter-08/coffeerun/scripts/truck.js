(function (window) {
  'use strict';
  var App = window.App || {};

  function Truck(truckId, db) {
    this.truckId = truckId;
    this.db = db;
  }

  Truck.prototype.createOrder = function (order) {
    console.log('Adding order for ' + order.emailAddress);
    this.db.add(order.emailAddress, order);
  };

  Truck.prototype.deliverOrder = function (customerId) {
    console.log('Delivering order for ' + customerId);
    this.db.remove(customerId);
  };

  Truck.prototype.printOrders = function () {
    var customerIdArray = Object.keys(this.db.getAll());

    console.log('Truck #' + this.truckId + ' has pending orders:');
    customerIdArray.forEach(function (id) {
      console.log(this.db.get(id));
    }.bind(this));
  };

  Truck.prototype.printOrders_bad = function () {
    var customerIdArray = Object.keys(this.db.getAll());

    console.log('Truck #' + this.truckId + ' has pending orders:');
    customerIdArray.forEach(function (id) {
      window.gthis = this;
      console.log(this.db.get(id));
    });
  };
  
  Truck.prototype.printOrders_closure = function () {
    var customerIdArray = Object.keys(this.db.getAll());

    console.log('Truck #' + this.truckId + ' has pending orders:');
    function makeClosure(that) { 
      return function (id) { console.log(that.db.get(id)); };
      }
    var closure = makeClosure(this);
    customerIdArray.forEach(closure);
  };

  Truck.prototype.printOrders_bind = function () {
    var customerIdArray = Object.keys(this.db.getAll());

    console.log('Truck #' + this.truckId + ' has pending orders:');
    var closure = function (id) { console.log(this.db.get(id)); }.bind(this);
    customerIdArray.forEach(closure);
  };

  App.Truck = Truck;
  window.App = App;
})(window);
