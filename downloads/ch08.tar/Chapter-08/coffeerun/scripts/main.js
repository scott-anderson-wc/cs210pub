(function (window) {
  'use strict';
  var App = window.App;
  var Truck = App.Truck;
  var DataStore = App.DataStore;

  var myTruck = new Truck('ncc-1701', new DataStore());
  window.myTruck = myTruck;
})(window);

(function () {
  var truck = new App.Truck('007', new App.DataStore());
  truck.createOrder({emailAddress: 'm@bond.com', coffee: 'earl grey'});
  truck.createOrder({emailAddress: 'dr@no.com', coffee: 'espresso'});
  truck.createOrder({emailAddress: 'oddjob@goldfinger.com', coffee: 'mocha latte'});
  window.truck1 = truck;
})();