// JavaScript File

/* global $, tileArray, blankTileRow, blankTileCol, getRightTile, getLeftTile, getAboveTile, getBelowTile
   global duration, updateData, movePicture, */
// This function can replace the previous one, adding the 'after' arg
//animate the selected tile in the direction specified by input
function movePicture(direction, tile, after) {
    if( tile == null) return;
    if( after == null ) after = function () {};
	var id = "#" + tile;
    var $elt = $(id);
	console.log("movePicture id " + id + " to direction: " + direction);
	
    var tileLeft = parseInt($elt.css("left"),10);
    var tileTop = parseInt($elt.css("top"),10);

    function done() { console.log("now at ",$elt.css("left")," and ",$elt.css("top")); }
	if(direction === "left") {
		$elt.animate({ left: tileLeft - 200 }, duration, after);
	}else if(direction === "right") {
		$elt.animate({ left: tileLeft + 200	}, duration, after);
	}else if(direction === "up") {
		$elt.animate({ top: tileTop - 200 }, duration, after);
	}else if(direction == "down") {
		$elt.animate({ top: tileTop + 200 }, duration, after);
	} else {
	    console.log("no such direction: "+direction);
	}
	
	updateData(direction, tile);
}

// replaces one of the same name in other file
function doMove(direction, after) {
    if(direction == "left") {
        movePicture("left",getRightTile());
    } else if( direction == "right") {
        movePicture("right",getLeftTile());
    } else if( direction == "up") {
        movePicture("up",getBelowTile());
    } else if( direction == "down") {
        movePicture("down",getAboveTile());
    } else {
        console.log("no such direction: "+direction);
    }
}

// This function replaces one of the same name, adding the 'after' arg
function doMove(direction, after) {
    if(direction == "left") {
        movePicture("left",getRightTile(), after);
    } else if( direction == "right") {
        movePicture("right",getLeftTile(), after);
    } else if( direction == "up") {
        movePicture("up",getBelowTile(), after);
    } else if( direction == "down") {
        movePicture("down",getAboveTile(), after);
    } else {
        console.log("no such direction: "+direction);
    }
}

document.addEventListener('keypress',function (eventObj) {
    
    var a_key = 97; //left
    var s_key = 115; //down
    var d_key = 100; //right
    var w_key = 119; //up
    
    if( eventObj.keyCode === a_key ) {
		console.log("a key pressed");
        doMove("left");
    } else if(eventObj.keyCode === d_key ) {
        doMove("right");
	} else if(eventObj.keyCode === w_key ) {
		console.log("w key pressed");
        doMove("up");
    } else if(eventObj.keyCode === s_key ) {
		console.log("s key pressed");
        doMove("down");
    } else {
    	//do nothing
    }
    
});

function randomElt(array) {
    return array[Math.floor(array.length*Math.random())];
}

function possibleMoves() {
    var moves = [];
    if( blankTileRow != 0) moves.push("down");
    if( blankTileRow != 2) moves.push("up");
    if( blankTileCol != 0) moves.push("right");
    if( blankTileCol != 2) moves.push("left");
    return moves;
}

var prevMove;

function possibleMovesNew() {
    var moves = [];
    if( blankTileRow != 0 && prevMove != "up") moves.push("down");
    if( blankTileRow != 2 && prevMove != "down" ) moves.push("up");
    if( blankTileCol != 0 && prevMove != "left") moves.push("right");
    if( blankTileCol != 2 && prevMove != "right") moves.push("left");
    return moves;
}

function randomMove() {
    var m = randomElt(possibleMovesNew());
    prevMove = m;
    return m;
}

function scrambleBoard(numMoves) {
    var m = randomMove();
    console.log('random move '+m);
    doMove(m,function () { if(numMoves>1) scrambleBoard(numMoves-1); });
}

function doMoveList(moves) {
    doMove(moves[0], function () { moves.shift(); doMoveList(moves); });
}

var rrl = ["right","right","left"];

$("#scrambleButton").click(function() { scrambleBoard(30); });
